$(function(){
    var myvar = 0;
    var GameSuccess = 0;
    var commonFunction ={
        //倒计时
        loading:function(){
            try{
                setTimeout(function () {
                    $(".loading").css({"display":"none"});
                }, 2600);
            }catch (error){
                reportError(error);
            }
        },
        //下落
        xialuo:function(){
            try{
                setTimeout(function () {
                    $(".start-main").animate({
                        position:'absolute',
                        top:'100%'
                    },45000);
                }, 2600);
            }catch (error){
                reportError(error);
            }
        },
        //点亮
        dianji:function(){
            $(".main-m").click(function(){
                $(".footer-m").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-e").click(function(){
                $(".footer-e").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-r").click(function(){
                $(".footer-r").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-r2").click(function(){
                $(".footer-r2").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-y").click(function(){
                $(".footer-y").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-c").click(function(){
                $(".footer-c").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-h").click(function(){
                $(".footer-h").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-r3").click(function(){
                $(".footer-r3").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-i").click(function(){
                $(".footer-i").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-s").click(function(){
                $(".footer-s").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-t").click(function(){
                $(".footer-t").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-m2").click(function(){
                $(".footer-m2").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-a").click(function(){
                $(".footer-a").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
            $(".main-s2").click(function(){
                $(".footer-s2").addClass("display-block");
                $(this).hide();
                commonFunction.chengon();
            });
        },
        //结束
        jieshu:function(){
            var GameTime = setInterval(function(){
                console.log(parseInt($(".start-main").css("top")),(parseInt($(".start-main").css("height"))*0.60))
                if(parseInt($(".start-main").css("top"))>=(parseInt($(".start-main").css("height"))*0.60)&&GameSuccess==0){
                    $(".gameOver").css({"display":"block"});
                    clearInterval(GameTime);
                }

            },1000)
        },
        //成功
        chengon:function(){
            myvar++;
            if(myvar==15){
                $(".gameOver").css({"display":"none"});
                $(".gameSuccess").css({"display":"block"});
                GameSuccess = 1;
            }
        },
        //重置
        reset:function(){
            try{
                $(".reset-btn").click(function(){
                    document.location.reload();
                })
            }catch (error){
                reportError(error);
            }
        },
        //折叠文字
        textOver:function(){
            try{
                $(".userGet .one").click(function(){
                    $(this).css({"display":"none"});
                    $(".userGet .two").css({"display":"block"});
                });
            }catch (error){
                reportError(error);
            }
        }
    };
    commonFunction.loading();
    commonFunction.xialuo();
    commonFunction.jieshu();
    commonFunction.dianji();
    commonFunction.reset();
    commonFunction.textOver();
});